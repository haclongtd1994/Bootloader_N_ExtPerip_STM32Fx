
#include "main.h"

#ifdef OSX_HOST

/* If you are here, then you may be trying to run this STM32_Programmer Application on OSX Host.
   Note1 : This file should implement the functions mentioned in the "OSxSerialPort.h"
   Note2 : Take a reference from the source file "WindowsSerialPort.c
 */

 #include "OSxSerialPort.h"

/* Code Begin */



/* Code End */

 #endif
